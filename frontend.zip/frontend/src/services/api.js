/**
 * IMS API Service
 * Interacts with the backend server running at /inventory (or http://localhost:8081/inventory)
 */

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8089';

async function handleResponse(response) {
  if (!response.ok) {
    let errorMsg = `Server error: ${response.status} ${response.statusText}`;
    try {
      const errorData = await response.json();
      if (errorData?.message) {
        errorMsg = errorData.message;
      } else if (errorData?.error) {
        errorMsg = typeof errorData.error === 'string' ? errorData.error : errorMsg;
      }
    } catch {
      // response wasn't JSON
    }
    const err = new Error(errorMsg);
    err.status = response.status;
    throw err;
  }

  // Handle plain text response (e.g. /health returns "Inventory service is UP")
  const contentType = response.headers.get('content-type');
  if (contentType && contentType.includes('application/json')) {
    return await response.json();
  }
  return await response.text();
}

export const api = {
  /**
   * Health check for backend connectivity
   */
  async checkHealth() {
    try {
      const res = await fetch(`${BASE_URL}/health`, { method: 'GET' });
      const text = await handleResponse(res);
      return { ok: true, message: text };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  },

  /**
   * Fetch all registered vendors
   * GET /inventory/vendors
   */
  async getVendors() {
    const res = await fetch(`${BASE_URL}/vendors`);
    return await handleResponse(res);
  },

  /**
   * Fetch all material categories
   * GET /inventory/categories
   */
  async getCategories() {
    const res = await fetch(`${BASE_URL}/categories`);
    return await handleResponse(res);
  },

  /**
   * Fetch material types and units for a selected category
   * POST /inventory/getUnitAndTypeList
   * @param {string} materialCategoryId
   */
  async getUnitAndTypeList(materialCategoryId) {
    const res = await fetch(`${BASE_URL}/getUnitAndTypeList`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ materialCategoryId }),
    });
    return await handleResponse(res);
  },

  /**
   * Create a new purchase order
   * POST /inventory/addPurchaseDetail
   * @param {Object} purchaseData
   */
  async addPurchaseDetail(purchaseData) {
    const res = await fetch(`${BASE_URL}/addPurchaseDetail`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(purchaseData),
    });
    return await handleResponse(res);
  },

  /**
   * Generate purchase report filtered by vendor and date range
   * POST /inventory/report/controller/getPurchaseDetails
   * @param {Object} filter { vendorName, fromDate, toDate }
   */
  async getPurchaseReport({ vendorName = '', fromDate = '', toDate = '' } = {}) {
    const res = await fetch(`${BASE_URL}/report/controller/getPurchaseDetails`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        vendorName: vendorName || '',
        fromDate: fromDate || '',
        toDate: toDate || '',
      }),
    });
    return await handleResponse(res);
  },

  async getAllPurchaseReports() {
  const res = await fetch(
    `${BASE_URL}/report/controller/getPurchaseDetails/all`,
    {
      method: 'GET',
    }
  );

  return await handleResponse(res);
},

  /**
   * Get system summary statistics
   * GET /inventory/stats
   */
  

  /**
   * Reset mock database to initial seed state
   * POST /inventory/reset
   */
  async resetData() {
    const res = await fetch(`${BASE_URL}/reset`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    return await handleResponse(res);
  },
};
