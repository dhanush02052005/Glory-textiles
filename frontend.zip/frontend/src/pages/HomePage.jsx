import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  ShoppingBag,
  IndianRupee,
  Building2,
  Layers,
  ArrowRight,
  TrendingUp,
  CheckCircle2,
} from 'lucide-react';
import { api } from '../services/api';

export const HomePage = ({ setActiveTab }) => {
  const [purchases, setPurchases] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch all purchase reports from the endpoint
  const fetchDashboardData = useCallback(async () => {
    try {
      setLoading(true);
      // Calls api.getAllPurchaseReports() or api.getPurchaseReport() depending on your api.js mapping
      const data = await api.getAllPurchaseReports();
      setPurchases(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
      setPurchases([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  // Compute stats dynamically from the purchase list
  const stats = useMemo(() => {
    if (!purchases.length) {
      return {
        totalPurchases: 0,
        totalAmount: 0,
        totalVendors: 0,
        totalCategories: 0,
      };
    }

    const totalPurchases = purchases.length;
    const totalAmount = purchases.reduce(
      (sum, p) => sum + (Number(p.purchaseAmount) || 0),
      0
    );

    // Calculate unique count of Vendors
    const uniqueVendors = new Set(
      purchases.map((p) => p.vendorName).filter(Boolean)
    );

    // Calculate unique count of Categories (or fallback to brandName/category field)
    const uniqueCategories = new Set(
      purchases
        .map((p) => p.categoryName || p.category || p.brandName)
        .filter(Boolean)
    );

    return {
      totalPurchases,
      totalAmount,
      totalVendors: uniqueVendors.size,
      totalCategories: uniqueCategories.size,
    };
  }, [purchases]);

  // Limit recent purchases to top 8 items
  // Sort purchases from newest to oldest before taking the first 8 items
const recentPurchases = useMemo(() => {
  return [...purchases]
    .sort((a, b) => new Date(b.purchaseDate) - new Date(a.purchaseDate) || (b.purchaseId - a.purchaseId))
    .slice(0, 8);
}, [purchases]);

  const formatCurrency = (val) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(val || 0);
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '-';
    const parsedDate = new Date(dateStr);
    return isNaN(parsedDate.getTime())
      ? dateStr
      : parsedDate.toLocaleDateString('en-IN', {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
        });
  };

  return (
    <div className="home-dashboard">
      {/* 4 Metric Cards */}
      <div className="metrics-row">
        <div className="metric-card">
          <div className="metric-header">
            <span className="metric-label">Total Purchases</span>
            <ShoppingBag size={18} className="metric-icon" />
          </div>
          <div className="metric-value">
            {loading ? '...' : stats.totalPurchases}
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-header">
            <span className="metric-label">Spend</span>
            <IndianRupee size={18} className="metric-icon" />
          </div>
          <div className="metric-value">
            {loading ? '...' : formatCurrency(stats.totalAmount)}
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-header">
            <span className="metric-label">Active Vendors</span>
            <Building2 size={18} className="metric-icon" />
          </div>
          <div className="metric-value">
            {loading ? '...' : stats.totalVendors}
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-header">
            <span className="metric-label">Categories</span>
            <Layers size={18} className="metric-icon" />
          </div>
          <div className="metric-value">
            {loading ? '...' : stats.totalCategories}
          </div>
        </div>
      </div>

      {/* Recent Purchases Panel */}
      <div className="card-panel">
        <div className="panel-header">
          <span className="panel-title">
            <TrendingUp size={20} color="var(--c-navy-800)" />
            Recent Orders
          </span>
          <button
            className="btn btn-ghost btn-sm"
            onClick={() => setActiveTab('reports')}
          >
            <span>View All Reports</span>
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="table-container">
          <table className="data-table-modern">
            <thead>
              <tr>
                <th>Order Ref</th>
                <th>Date</th>
                <th>Vendor</th>
                <th>Brand / Item</th>
                <th>Qty</th>
                <th>Amount (₹)</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={7} style={{ textAlign: 'center', padding: '3rem' }}>
                    <div className="spinner spinner-sm" />
                  </td>
                </tr>
              ) : recentPurchases.length === 0 ? (
                <tr>
                  <td
                    colSpan={7}
                    style={{
                      textAlign: 'center',
                      padding: '3rem',
                      color: 'var(--c-text-muted)',
                    }}
                  >
                    No purchase orders recorded yet. Click "Enter Purchase Order" to record your first order.
                  </td>
                </tr>
              ) : (
                recentPurchases.map((p, idx) => (
                  <tr key={p.purchaseId || p.transactionId || idx}>
                    <td>
                      <span className="order-ref-pill">{p.purchaseId || `#PO-${idx + 1}`}</span>
                    </td>
                    <td style={{ fontSize: '0.85rem' }}>{formatDate(p.purchaseDate)}</td>
                    <td style={{ fontWeight: 600, color: 'var(--c-navy-800)' }}>
                      {p.vendorName || '-'}
                    </td>
                    <td>{p.brandName || p.itemName || '-'}</td>
                    <td style={{ fontWeight: 700 }}>{p.quantity || 0}</td>
                    <td style={{ fontWeight: 800, color: 'var(--c-navy-800)' }}>
                      {formatCurrency(p.purchaseAmount)}
                    </td>
                    <td>
                      <span className="status-pill completed">
                        <CheckCircle2 size={12} />
                        {p.status || 'Completed'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};