import React from 'react';
import {
  Check,
  PlusCircle,
  FileSpreadsheet,
  Printer,
  ArrowLeft,
  Copy,
} from 'lucide-react';
import { useToast } from '../components/common/Toast';

export const PurchaseSuccessConfirmation = ({
  purchase,
  onNewOrder,
  onViewReports,
  onBackHome,
}) => {
  const { addToast } = useToast();

  if (!purchase) {
    return (
      <div style={{ textAlign: 'center', padding: '4rem 1rem' }}>
        <p>No purchase record selected.</p>
        <button className="btn btn-yellow" onClick={onNewOrder} style={{ marginTop: '1rem' }}>
          Enter Purchase Order
        </button>
      </div>
    );
  }

  const formatCurrency = (val) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(val || 0);
  };

  const handleCopyId = () => {
    if (purchase.transactionId) {
      navigator.clipboard.writeText(purchase.transactionId);
      addToast(`Copied ${purchase.transactionId}`, 'success');
    }
  };

  return (
    <div className="ticket-container">
      <div className="ticket-card">
        {/* Dark Navy Ticket Header */}
        <div className="ticket-header-dark">
          <div className="ticket-seal">
            <Check size={36} strokeWidth={3} />
          </div>
          <h2 style={{ fontSize: '1.65rem', fontWeight: 800, color: 'var(--c-white)', marginBottom: '0.35rem' }}>
            Purchase Order Recorded
          </h2>
          <p style={{ color: '#CBD5E1', fontSize: '0.88rem' }}>
            Transaction confirmed and committed to in-memory database.
          </p>

          <div className="ticket-ids-pill">
            <span>Ref: {purchase.purchaseId}</span>
            <span>&bull;</span>
            <span
              onClick={handleCopyId}
              style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 4 }}
              title="Click to copy Transaction ID"
            >
              Txn: {purchase.transactionId}
              <Copy size={13} />
            </span>
          </div>
        </div>

        {/* Ticket Body Content */}
        <div className="ticket-body-content">
          <div className="ticket-field-list">
            <div className="ticket-meta-block">
              <span className="ticket-meta-label">Vendor Supplier</span>
              <span className="ticket-meta-val" style={{ color: 'var(--c-navy-800)' }}>
                {purchase.vendorName}
              </span>
            </div>

            <div className="ticket-meta-block">
              <span className="ticket-meta-label">Purchase Date</span>
              <span className="ticket-meta-val">{purchase.purchaseDate}</span>
            </div>

            <div className="ticket-meta-block">
              <span className="ticket-meta-label">Material Category</span>
              <span className="ticket-meta-val">
                {purchase.categoryName || purchase.materialCategoryId}
              </span>
            </div>

            <div className="ticket-meta-block">
              <span className="ticket-meta-label">Material Type</span>
              <span className="ticket-meta-val">
                {purchase.typeName || purchase.materialTypeId || 'N/A'}
              </span>
            </div>

            <div className="ticket-meta-block">
              <span className="ticket-meta-label">Specification / Brand</span>
              <span className="ticket-meta-val">{purchase.brandName}</span>
            </div>

            <div className="ticket-meta-block">
              <span className="ticket-meta-label">Quantity Ordered</span>
              <span className="ticket-meta-val">
                {purchase.quantity} {purchase.unitName || purchase.unitId || 'Units'}
              </span>
            </div>
          </div>

          {/* Grand Total Highlight */}
          <div className="ticket-grand-total">
            <span style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--c-navy-800)' }}>
              Total Amount
            </span>
            <span className="amount">{formatCurrency(purchase.purchaseAmount)}</span>
          </div>

          {/* Simulated Authentic Barcode */}
          <div className="ticket-barcode">
            <div className="barcode-lines" />
            <span className="barcode-text">{purchase.transactionId}</span>
          </div>

          {/* Action Buttons */}
          <div
            className="no-print"
            style={{
              marginTop: '2rem',
              display: 'flex',
              gap: '0.85rem',
              flexWrap: 'wrap',
            }}
          >
            <button className="btn btn-yellow" onClick={onNewOrder} style={{ flex: 1.2 }}>
              <PlusCircle size={16} />
              <span>Create Another Order</span>
            </button>

            <button
              className="btn btn-navy"
              onClick={() => onViewReports(purchase.vendorName)}
              style={{ flex: 1 }}
            >
              <FileSpreadsheet size={16} />
              <span>View in Reports</span>
            </button>

            <button className="btn btn-ghost" onClick={() => window.print()}>
              <Printer size={16} />
              <span>Print Voucher</span>
            </button>
          </div>

          <div className="no-print" style={{ textAlign: 'center', marginTop: '1.25rem' }}>
            <button
              className="btn btn-ghost btn-sm"
              onClick={onBackHome}
              style={{ border: 'none', color: 'var(--c-text-muted)' }}
            >
              <ArrowLeft size={14} />
              <span>Back to Dashboard</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
