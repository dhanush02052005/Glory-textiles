import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  RotateCcw,
  AlertCircle,
  Package,
} from 'lucide-react';
import { api } from '../services/api';
import { useToast } from '../components/common/Toast';

const INITIAL_FORM = {
  vendorName: '',
  materialCategoryId: '',
  materialTypeId: '',
  unitId: '',
  brandName: '',
  quantity: '',
  purchaseDate: new Date().toISOString().split('T')[0],
  purchaseAmount: '',
};

export const PurchaseOrderForm = ({ onSuccess, onCancel }) => {
  const { addToast } = useToast();

  // Data Sources
  const [vendors, setVendors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [materialTypes, setMaterialTypes] = useState([]);
  const [units, setUnits] = useState([]);

  // Loading States
  const [loading, setLoading] = useState(true);
  const [loadingTypes, setLoadingTypes] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form & Validations
  const [formData, setFormData] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  const fieldRefs = {
    vendorName: useRef(null),
    materialCategoryId: useRef(null),
    materialTypeId: useRef(null),
    unitId: useRef(null),
    brandName: useRef(null),
    quantity: useRef(null),
    purchaseAmount: useRef(null),
    purchaseDate: useRef(null),
  };

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const [vList, cList] = await Promise.all([
          api.getVendors(),
          api.getCategories(),
        ]);
        setVendors(Array.isArray(vList) ? vList : []);
        setCategories(Array.isArray(cList) ? cList : []);
      } catch (err) {
        addToast(`Could not load options: ${err.message}`, 'error');
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [addToast]);

  // Dynamic Type & Unit fetching on Category change
  useEffect(() => {
    if (!formData.materialCategoryId) {
      setMaterialTypes([]);
      setUnits([]);
      return;
    }

    async function fetchUnitsAndTypes() {
      try {
        setLoadingTypes(true);
        const res = await api.getUnitAndTypeList(formData.materialCategoryId);
        setMaterialTypes(res.materialTypeList || []);
        setUnits(res.unitList || []);
      } catch (err) {
        addToast(`Error fetching material types: ${err.message}`, 'error');
      } finally {
        setLoadingTypes(false);
      }
    }
    fetchUnitsAndTypes();
  }, [formData.materialCategoryId, addToast]);

  // Field validation
  const validateField = (name, value) => {
    let error = '';
    switch (name) {
      case 'vendorName':
        if (!value || !value.trim()) error = 'Vendor is required';
        break;
      case 'materialCategoryId':
        if (!value || !value.trim()) error = 'Category is required';
        break;
      case 'materialTypeId':
        if (!value || !value.trim()) error = 'Material type is required';
        break;
      case 'unitId':
        if (!value || !value.trim()) error = 'Unit is required';
        break;
      case 'brandName':
        if (!value || !value.trim()) {
          error = 'Brand name is required';
        } else if (value.trim().length < 2) {
          error = 'Brand must be at least 2 characters';
        }
        break;
      case 'quantity':
        if (value === '' || value === null) {
          error = 'Quantity is required';
        } else {
          const num = Number(value);
          if (isNaN(num) || num <= 0) error = 'Enter a valid quantity > 0';
        }
        break;
      case 'purchaseAmount':
        if (value === '' || value === null) {
          error = 'Amount is required';
        } else {
          const amt = Number(value);
          if (isNaN(amt) || amt <= 0) error = 'Enter a valid amount > 0';
        }
        break;
      case 'purchaseDate':
        if (!value || !value.trim()) {
          error = 'Date is required';
        } else {
          const today = new Date().toISOString().split('T')[0];

          if (value > today) {
            error = 'Purchase date cannot be a future date';
          }
        }
        break;
      default:
        break;
    }
    return error;
  };

  const validateAll = () => {
    const newErrors = {};
    Object.keys(INITIAL_FORM).forEach((field) => {
      const err = validateField(field, formData[field]);
      if (err) newErrors[field] = err;
    });
    setErrors(newErrors);
    return newErrors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => {
      const updated = { ...prev, [name]: value };
      if (name === 'materialCategoryId') {
        updated.materialTypeId = '';
        updated.unitId = '';
      }
      return updated;
    });

    if (touched[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: validateField(name, value),
      }));
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors((prev) => ({
      ...prev,
      [name]: validateField(name, value),
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const allTouched = Object.keys(INITIAL_FORM).reduce((acc, curr) => {
      acc[curr] = true;
      return acc;
    }, {});
    setTouched(allTouched);

    const validationErrors = validateAll();
    const errorKeys = Object.keys(validationErrors);

    if (errorKeys.length > 0) {
      if (fieldRefs[errorKeys[0]]?.current) {
        fieldRefs[errorKeys[0]].current.focus();
      }
      addToast('Please complete all mandatory fields.', 'error');
      return;
    }

    try {
      setSubmitting(true);

      // Find names from the selected IDs
      const matchedCategory = categories.find(
        (c) => c.categoryId === formData.materialCategoryId
      );

      const matchedType = materialTypes.find(
        (t) => t.typeId === formData.materialTypeId
      );

      const matchedUnit = units.find(
        (u) => u.unitId === formData.unitId
      );

      const payload = {
        vendorName: formData.vendorName.trim(),

        // IDs
        materialCategoryId: formData.materialCategoryId.trim(),
        materialTypeId: formData.materialTypeId.trim(),
        unitId: formData.unitId.trim(),

        // Names
        categoryName: matchedCategory?.categoryName || '',
        materialTypeName: matchedType?.typeName || '',
        unitName: matchedUnit?.unitName || '',

        // Other details
        brandName: formData.brandName.trim(),
        quantity: Number(formData.quantity),
        purchaseDate: formData.purchaseDate,
        purchaseAmount: Number(formData.purchaseAmount),
      };

      const purchaseData = {
        ...payload,
        materialCategoryName: matchedCategory?.categoryName || payload.materialCategoryName,
        materialTypeName: matchedType?.typeName || payload.materialTypeName,
        materialUnitName: matchedUnit?.unitName || payload.materialUnitName,

      }

      console.log("PAYLOAD SENT TO BACKEND:", purchaseData);

      const response = await api.addPurchaseDetail(purchaseData);

      console.log("FULL RESPONSE:", response);

      if (response && response.status === 'SUCCESS') {
        addToast('Purchase order saved successfully!', 'success');

        if (onSuccess) {
          onSuccess({
            ...response.purchase,
            categoryName: matchedCategory?.categoryName || payload.categoryName,
            typeName: matchedType?.typeName || payload.materialTypeName,
            unitName: matchedUnit?.unitName || payload.unitName,
          });
        }
      }
    } catch (err) {
      addToast(`Error: ${err.message}`, 'error');
    } finally {
      setSubmitting(false);
    }
  }

  const handleReset = () => {
    setFormData(INITIAL_FORM);
    setErrors({});
    setTouched({});
  };

  const getStatusClass = (field) => {
    if (touched[field] && errors[field]) return 'is-invalid';
    if (touched[field] && !errors[field] && formData[field]) return 'is-valid';
    return '';
  };

  return (
    <div style={{ maxWidth: 840, margin: '0 auto' }}>
      <div className="card-panel">
        <div className="panel-header">
          <span className="panel-title">
            <Package size={20} color="var(--c-navy-800)" />
            Purchase Order Information
          </span>
          <span style={{ fontSize: '0.8rem', color: 'var(--c-text-muted)', fontWeight: 600 }}>
            * Mandatory fields
          </span>
        </div>

        <div className="panel-body">
          {loading ? (
            <div style={{ textAlign: 'center', padding: '3rem' }}>
              <div className="spinner spinner-sm" />
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate>
              <div className="form-grid-modern">
                {/* 1. Vendor Selection */}
                <div className="field-block">
                  <label className="field-label" htmlFor="vendorName">
                    <span>Vendor Name <span className="req-marker">*</span></span>
                  </label>
                  <select
                    id="vendorName"
                    name="vendorName"
                    ref={fieldRefs.vendorName}
                    value={formData.vendorName}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={`field-input ${getStatusClass('vendorName')}`}
                  >
                    <option value="">-- Choose Vendor --</option>
                    {vendors.map((v) => (
                      <option key={v.vendorId || v.vendorName} value={v.vendorName}>
                        {v.vendorName}
                      </option>
                    ))}
                  </select>
                  {touched.vendorName && errors.vendorName && (
                    <span className="field-error-text">
                      <AlertCircle size={13} /> {errors.vendorName}
                    </span>
                  )}
                </div>

                {/* 2. Material Category */}
                <div className="field-block">
                  <label className="field-label" htmlFor="materialCategoryId">
                    <span>Material Category <span className="req-marker">*</span></span>
                  </label>
                  <select
                    id="materialCategoryId"
                    name="materialCategoryId"
                    ref={fieldRefs.materialCategoryId}
                    value={formData.materialCategoryId}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={`field-input ${getStatusClass('materialCategoryId')}`}
                  >
                    <option value="">-- Choose Category --</option>
                    {categories.map((c) => (
                      <option key={c.categoryId} value={c.categoryId}>
                        {c.categoryName}
                      </option>
                    ))}
                  </select>
                  {touched.materialCategoryId && errors.materialCategoryId && (
                    <span className="field-error-text">
                      <AlertCircle size={13} /> {errors.materialCategoryId}
                    </span>
                  )}
                </div>

                {/* 3. Material Type */}
                <div className="field-block">
                  <label className="field-label" htmlFor="materialTypeId">
                    <span>Material Type <span className="req-marker">*</span></span>
                    {loadingTypes && <span style={{ fontSize: '0.72rem', color: 'var(--c-navy-500)' }}>Fetching...</span>}
                  </label>
                  <select
                    id="materialTypeId"
                    name="materialTypeId"
                    ref={fieldRefs.materialTypeId}
                    value={formData.materialTypeId}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    disabled={!formData.materialCategoryId || loadingTypes}
                    className={`field-input ${getStatusClass('materialTypeId')}`}
                  >
                    <option value="">
                      {!formData.materialCategoryId ? 'Select Category First' : '-- Select Material Type --'}
                    </option>
                    {materialTypes.map((t) => (
                      <option key={t.typeId} value={t.typeId}>
                        {t.typeName}
                      </option>
                    ))}
                  </select>
                  {touched.materialTypeId && errors.materialTypeId && (
                    <span className="field-error-text">
                      <AlertCircle size={13} /> {errors.materialTypeId}
                    </span>
                  )}
                </div>

                {/* 4. Unit of Measurement */}
                <div className="field-block">
                  <label className="field-label" htmlFor="unitId">
                    <span>Unit of Measure <span className="req-marker">*</span></span>
                  </label>
                  <select
                    id="unitId"
                    name="unitId"
                    ref={fieldRefs.unitId}
                    value={formData.unitId}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    disabled={!formData.materialCategoryId || loadingTypes}
                    className={`field-input ${getStatusClass('unitId')}`}
                  >
                    <option value="">
                      {!formData.materialCategoryId ? 'Select Category First' : '-- Select Measuring Unit --'}
                    </option>
                    {units.map((u) => (
                      <option key={u.unitId} value={u.unitId}>
                        {u.unitName}
                      </option>
                    ))}
                  </select>
                  {touched.unitId && errors.unitId && (
                    <span className="field-error-text">
                      <AlertCircle size={13} /> {errors.unitId}
                    </span>
                  )}
                </div>

                {/* 5. Brand Name */}
                <div className="field-block full">
                  <label className="field-label" htmlFor="brandName">
                    <span>Brand Name / Item Model <span className="req-marker">*</span></span>
                  </label>
                  <input
                    type="text"
                    id="brandName"
                    name="brandName"
                    ref={fieldRefs.brandName}
                    placeholder="e.g. Tata Steel Tiscon 500D"
                    value={formData.brandName}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={`field-input ${getStatusClass('brandName')}`}
                  />
                  {touched.brandName && errors.brandName && (
                    <span className="field-error-text">
                      <AlertCircle size={13} /> {errors.brandName}
                    </span>
                  )}
                </div>

                {/* 6. Quantity */}
                <div className="field-block">
                  <label className="field-label" htmlFor="quantity">
                    <span>Quantity <span className="req-marker">*</span></span>
                  </label>
                  <input
                    type="number"
                    id="quantity"
                    name="quantity"
                    ref={fieldRefs.quantity}
                    placeholder="e.g. 150"
                    min="1"
                    value={formData.quantity}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={`field-input ${getStatusClass('quantity')}`}
                  />
                  {touched.quantity && errors.quantity && (
                    <span className="field-error-text">
                      <AlertCircle size={13} /> {errors.quantity}
                    </span>
                  )}
                </div>

                {/* 7. Purchase Amount */}
                <div className="field-block">
                  <label className="field-label" htmlFor="purchaseAmount">
                    <span>Purchase Amount (₹) <span className="req-marker">*</span></span>
                  </label>
                  <input
                    type="number"
                    id="purchaseAmount"
                    name="purchaseAmount"
                    ref={fieldRefs.purchaseAmount}
                    placeholder="e.g. 75000"
                    min="1"
                    value={formData.purchaseAmount}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={`field-input ${getStatusClass('purchaseAmount')}`}
                  />
                  {touched.purchaseAmount && errors.purchaseAmount && (
                    <span className="field-error-text">
                      <AlertCircle size={13} /> {errors.purchaseAmount}
                    </span>
                  )}
                </div>

                {/* 8. Purchase Date */}
                <div className="field-block full">
                  <label className="field-label" htmlFor="purchaseDate">
                    <span>Purchase Date <span className="req-marker">*</span></span>
                  </label>
                  <input
                    type="date"
                    id="purchaseDate"
                    name="purchaseDate"
                    ref={fieldRefs.purchaseDate}
                    value={formData.purchaseDate}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    max={new Date().toISOString().split('T')[0]}
                    className={`field-input ${getStatusClass('purchaseDate')}`}
                  />
                  {touched.purchaseDate && errors.purchaseDate && (
                    <span className="field-error-text">
                      <AlertCircle size={13} /> {errors.purchaseDate}
                    </span>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div style={{ marginTop: '1.75rem', display: 'flex', justifyContent: 'flex-end', gap: '0.85rem' }}>
                <button
                  type="button"
                  className="btn btn-ghost"
                  onClick={handleReset}
                  disabled={submitting}
                >
                  <RotateCcw size={15} />
                  <span>Reset Form</span>
                </button>

                <button
                  type="submit"
                  className="btn btn-yellow"
                  disabled={submitting}
                >
                  {submitting ? (
                    <div className="spinner spinner-sm spinner-yellow" />
                  ) : (
                    <Send size={16} />
                  )}
                  <span>Submit Purchase Order</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
