import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  FileSpreadsheet,
  RotateCcw,
  AlertCircle,
  Search,
  CheckCircle2,
} from 'lucide-react';
import { api } from '../services/api';
import { useToast } from '../components/common/Toast';

export const PurchaseReports = ({ initialVendor = '' }) => {
  const { addToast } = useToast();

  // Filters
  const [vendorList, setVendorList] = useState([]);
  const [selectedVendor, setSelectedVendor] = useState(initialVendor);
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [dateError, setDateError] = useState('');

  // Report Data
  const [reportData, setReportData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    async function loadVendors() {
      try {
        const list = await api.getVendors();
        setVendorList(Array.isArray(list) ? list : []);
      } catch (err) {
        console.error(err);
      }
    }
    loadVendors();
  }, []);

  useEffect(() => {
    if (initialVendor) {
      setSelectedVendor(initialVendor);
    }
  }, [initialVendor]);

  // Date range validation
  const validateDates = (start, end) => {
    if (start && end && start > end) {
      return '"From Date" cannot be after "To Date"';
    }
    return '';
  };

  const handleFromChange = (e) => {
    const val = e.target.value;
    setFromDate(val);
    setDateError(validateDates(val, toDate));
  };

  const handleToChange = (e) => {
    const val = e.target.value;
    setToDate(val);
    setDateError(validateDates(fromDate, val));
  };

  // Quick Preset Filters
  const applyPreset = (preset) => {
    const today = new Date();
    const toStr = today.toISOString().split('T')[0];
    let from = new Date();

    if (preset === '30d') {
      from.setDate(today.getDate() - 30);
    } else if (preset === '90d') {
      from.setDate(today.getDate() - 90);
    } else if (preset === 'ytd') {
      from = new Date(today.getFullYear(), 0, 1);
    } else if (preset === 'all') {
      setFromDate('');
      setToDate('');
      setDateError('');
      return;
    }

    setFromDate(from.toISOString().split('T')[0]);
    setToDate(toStr);
    setDateError('');
  };

  // Fetch report
  const handleGenerateReport = useCallback(
    async (vendorOverride) => {
      const v =
        vendorOverride !== undefined ? vendorOverride : selectedVendor;

      const err = validateDates(fromDate, toDate);

      if (err) {
        setDateError(err);
        addToast(err, 'error');
        return;
      }

      try {
        setLoading(true);

        let data;

        // No filters -> GET all purchase reports
        if (!v && !fromDate && !toDate) {
          data = await api.getAllPurchaseReports();
        }
        // Any filter selected -> POST filtered report
        else {
          data = await api.getPurchaseReport({
            vendorName: v || '',
            fromDate: fromDate || '',
            toDate: toDate || '',
          });
        }

        setReportData(Array.isArray(data) ? data : []);
      } catch (err) {
        addToast(`Report failed: ${err.message}`, 'error');
      } finally {
        setLoading(false);
      }
    },
    [selectedVendor, fromDate, toDate, addToast]
  );

  useEffect(() => {
    handleGenerateReport(initialVendor);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleReset = () => {
    setSelectedVendor('');
    setFromDate('');
    setToDate('');
    setDateError('');
    setSearchTerm('');
    handleGenerateReport('');
  };

  const formatCurrency = (val) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(val || 0);
  };

  // Filtered by in-table search
  const filteredRecords = useMemo(() => {
    if (!searchTerm.trim()) return reportData;
    const q = searchTerm.toLowerCase();
    return reportData.filter(
      (r) =>
        r.purchaseId?.toLowerCase().includes(q) ||
        r.vendorName?.toLowerCase().includes(q) ||
        r.brandName?.toLowerCase().includes(q) ||
        r.materialCategoryId?.toLowerCase().includes(q)
    );
  }, [reportData, searchTerm]);

  // Aggregate Metrics
  const summary = useMemo(() => {
    const count = filteredRecords.length;
    const totalAmount = filteredRecords.reduce((acc, r) => acc + (Number(r.purchaseAmount) || 0), 0);
    const avgAmount = count > 0 ? totalAmount / count : 0;
    return { count, totalAmount, avgAmount };
  }, [filteredRecords]);

  // Export CSV
  const handleExportCSV = () => {
    if (filteredRecords.length === 0) {
      addToast('No data to export', 'info');
      return;
    }

    const headers = ['Order Ref', 'Date', 'Vendor', 'Brand', 'Qty', 'Amount (INR)', 'Status'];
    const rows = filteredRecords.map((r) => [
      `"${r.purchaseId || ''}"`,
      `"${r.purchaseDate || ''}"`,
      `"${(r.vendorName || '').replace(/"/g, '""')}"`,
      `"${(r.brandName || '').replace(/"/g, '""')}"`,
      r.quantity || 0,
      r.purchaseAmount || 0,
      `"${r.status || 'Completed'}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const link = document.createElement('a');
    link.href = encodeURI(csvContent);
    link.download = `purchase_report_${selectedVendor || 'all'}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast('CSV downloaded successfully', 'success');
  };

  return (
    <div className="reports-page">
      {/* Top Filter Card */}
      <div className="filter-card no-print">


        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleGenerateReport();
          }}
        >
          <div className="filter-grid">
            {/* Vendor Selector */}
            <div className="field-block">
              <label className="field-label" htmlFor="filterVendor">
                Select Vendor Supplier
              </label>
              <select
                id="filterVendor"
                className="field-input"
                value={selectedVendor}
                onChange={(e) => setSelectedVendor(e.target.value)}
              >
                <option value="">All Registered Vendors</option>
                {vendorList.map((v) => (
                  <option key={v.vendorId || v.vendorName} value={v.vendorName}>
                    {v.vendorName}
                  </option>
                ))}
              </select>
            </div>

            {/* From Date */}
            <input
              type="date"
              id="filterFromDate"
              className={`field-input ${dateError ? 'is-invalid' : ''}`}
              value={fromDate}
              onChange={handleFromChange}
              max={new Date().toISOString().split('T')[0]}
            />

            {/* To Date */}
            <input
              type="date"
              id="filterToDate"
              className={`field-input ${dateError ? 'is-invalid' : ''}`}
              value={toDate}
              onChange={handleToChange}
              max={new Date().toISOString().split('T')[0]}
            />

            {/* Action Buttons */}
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <button
                type="button"
                className="btn btn-ghost"
                onClick={handleReset}
                disabled={loading}
                title="Clear all filters"
              >
                <RotateCcw size={15} />
              </button>
              <button
                type="submit"
                className="btn btn-yellow"
                disabled={loading || !!dateError}
              >
                {loading ? (
                  <div className="spinner spinner-sm spinner-yellow" />
                ) : (
                  <FileSpreadsheet size={16} />
                )}
                <span>Generate Report</span>
              </button>
            </div>
          </div>

          {dateError && (
            <div className="field-error-text" style={{ marginTop: '0.75rem' }}>
              <AlertCircle size={14} /> {dateError}
            </div>
          )}
        </form>
      </div>

      {/* Modern Aggregate Metrics Strip */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '1rem',
          marginBottom: '1.5rem',
        }}
      >
        <div
          style={{
            background: 'var(--c-white)',
            border: '1px solid var(--c-card-border)',
            borderRadius: 'var(--r-md)',
            padding: '1rem 1.25rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--c-text-muted)', textTransform: 'uppercase' }}>
            Matching Orders
          </span>
          <span style={{ fontFamily: 'var(--font-heading)', fontSize: '1.4rem', fontWeight: 800, color: 'var(--c-navy-800)' }}>
            {summary.count}
          </span>
        </div>

        <div
          style={{
            background: 'var(--c-white)',
            border: '1px solid var(--c-card-border)',
            borderRadius: 'var(--r-md)',
            padding: '1rem 1.25rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--c-text-muted)', textTransform: 'uppercase' }}>
            Total Spend
          </span>
          <span style={{ fontFamily: 'var(--font-heading)', fontSize: '1.4rem', fontWeight: 800, color: 'var(--c-navy-800)' }}>
            {formatCurrency(summary.totalAmount)}
          </span>
        </div>

        <div
          style={{
            background: 'var(--c-white)',
            border: '1px solid var(--c-card-border)',
            borderRadius: 'var(--r-md)',
            padding: '1rem 1.25rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--c-text-muted)', textTransform: 'uppercase' }}>
            Average Ticket
          </span>
          <span style={{ fontFamily: 'var(--font-heading)', fontSize: '1.4rem', fontWeight: 800, color: 'var(--c-navy-800)' }}>
            {formatCurrency(summary.avgAmount)}
          </span>
        </div>
      </div>

      {/* Results Table Panel */}
      <div className="table-panel">
        <div className="table-panel-header no-print">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <span style={{ fontFamily: 'var(--font-heading)', fontSize: '1.15rem', fontWeight: 800, color: 'var(--c-navy-800)' }}>
              Statement
            </span>
            {selectedVendor && (
              <span
                style={{
                  background: 'var(--c-navy-800)',
                  color: 'var(--c-yellow-500)',
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  padding: '0.2rem 0.65rem',
                  borderRadius: 'var(--r-full)',
                }}
              >
                {selectedVendor}
              </span>
            )}
          </div>

          {/* In-table search + Print / CSV actions */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
            <div style={{ position: 'relative' }}>
              <input
                type="text"
                placeholder="Search statements..."
                className="field-input"
                style={{ height: 38, width: 200, fontSize: '0.82rem', paddingLeft: '2rem' }}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search size={14} style={{ position: 'absolute', left: 10, top: 12, color: 'var(--c-text-muted)' }} />
            </div>

          </div>
        </div>

        <div className="table-container">
          <table className="data-table-modern">
            <thead>
              <tr>
                <th>Order Ref</th>
                <th>Date</th>
                <th>Vendor</th>
                <th>Brand / Spec</th>
                <th>Qty</th>
                <th>Amount (₹)</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={7} style={{ textAlign: 'center', padding: '3.5rem' }}>
                    <div className="spinner spinner-sm" />
                  </td>
                </tr>
              ) : filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={7} style={{ textAlign: 'center', padding: '3.5rem', color: 'var(--c-text-muted)' }}>
                    No purchase orders found matching the filter criteria.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((row) => (
                  <tr key={row.purchaseId || row.transactionId}>
                    <td>
                      <span className="order-ref-pill">{row.purchaseId}</span>
                    </td>
                    <td style={{ fontSize: '0.85rem' }}>{row.purchaseDate}</td>
                    <td style={{ fontWeight: 600, color: 'var(--c-navy-800)' }}>
                      {row.vendorName}
                    </td>
                    <td>
                      <span style={{ fontWeight: 600 }}>{row.brandName}</span>
                    </td>
                    <td style={{ fontWeight: 700 }}>{row.quantity}</td>
                    <td style={{ fontWeight: 800, color: 'var(--c-navy-800)' }}>
                      {formatCurrency(row.purchaseAmount)}
                    </td>
                    <td>
                      <span className="status-pill completed">
                        <CheckCircle2 size={12} />
                        {row.status || 'Completed'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
