import React from 'react';

/**
 * Reusable Spinner component
 */
export const Spinner = ({ size = 'md', color = 'primary', className = '' }) => {
  const sizeClass = size === 'sm' ? 'spinner-sm' : size === 'lg' ? 'spinner-lg' : 'spinner-md';
  const colorClass = color === 'white' ? 'spinner-white' : '';
  return <div className={`spinner ${sizeClass} ${colorClass} ${className}`} role="status" aria-label="Loading" />;
};

/**
 * Skeleton Card for metric widgets
 */
export const SkeletonCard = () => (
  <div className="stat-card">
    <div className="skeleton" style={{ width: 48, height: 48, borderRadius: 10 }} />
    <div className="stat-content" style={{ gap: 8, width: '100%' }}>
      <div className="skeleton" style={{ width: '60%', height: 14 }} />
      <div className="skeleton" style={{ width: '80%', height: 24 }} />
    </div>
  </div>
);

/**
 * Skeleton rows for tables
 */
export const SkeletonTableRows = ({ rows = 5, cols = 6 }) => {
  return (
    <>
      {Array.from({ length: rows }).map((_, rIdx) => (
        <tr key={rIdx}>
          {Array.from({ length: cols }).map((_, cIdx) => (
            <td key={cIdx}>
              <div className="skeleton" style={{ height: 16, width: cIdx === 0 ? '70%' : '90%' }} />
            </td>
          ))}
        </tr>
      ))}
    </>
  );
};

/**
 * Full Page Loader
 */
export const PageLoader = ({ message = 'Loading system data...' }) => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 300, gap: 16 }}>
    <Spinner size="lg" />
    <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9rem', fontWeight: 500 }}>{message}</p>
  </div>
);
