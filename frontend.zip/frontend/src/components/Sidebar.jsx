import React from 'react';
import {
  LayoutDashboard,
  PlusCircle,
  FileSpreadsheet,
} from 'lucide-react';

export const Sidebar = ({ activeTab, setActiveTab }) => {
  return (
    <aside className="app-sidebar no-print">
      <div className="sidebar-header">
        <span className="brand-main-title">GLORY TEXTILES</span>
      </div>

      <nav className="sidebar-nav">

        <button
          className={`sidebar-link ${activeTab === 'home' ? 'active' : ''}`}
          onClick={() => setActiveTab('home')}
        >
          <LayoutDashboard size={19} />
          <span>Dashboard</span>
        </button>

        <button
          className={`sidebar-link ${activeTab === 'new-po' ? 'active' : ''}`}
          onClick={() => setActiveTab('new-po')}
        >
          <PlusCircle size={19} />
          <span>Enter Purchase Order</span>
        </button>

        <button
          className={`sidebar-link ${activeTab === 'reports' ? 'active' : ''}`}
          onClick={() => setActiveTab('reports')}
        >
          <FileSpreadsheet size={19} />
          <span>Purchase Reports</span>
        </button>
      </nav>

    </aside>
  );
};
