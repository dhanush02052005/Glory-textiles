import React, { useState } from 'react';
import { ToastProvider } from './components/common/Toast';
import { Sidebar } from './components/Sidebar';
import { HomePage } from './pages/HomePage';
import { PurchaseOrderForm } from './pages/PurchaseOrderForm';
import { PurchaseSuccessConfirmation } from './pages/PurchaseSuccessConfirmation';
import { PurchaseReports } from './pages/PurchaseReports';
import { Calendar, PlusCircle } from 'lucide-react';

export function AppContent() {
  const [activeTab, setActiveTab] = useState('home'); // 'home' | 'new-po' | 'confirmation' | 'reports'
  const [lastCreatedPurchase, setLastCreatedPurchase] = useState(null);
  const [reportVendorFilter, setReportVendorFilter] = useState('');

  const handlePurchaseSuccess = (newPurchase) => {
    setLastCreatedPurchase(newPurchase);
    setActiveTab('confirmation');
  };

  const handleCreateAnother = () => {
    setLastCreatedPurchase(null);
    setActiveTab('new-po');
  };

  const handleViewVendorReports = (vendorName) => {
    setReportVendorFilter(vendorName || '');
    setActiveTab('reports');
  };

  // Formatted current date for top action bar
  const todayFormatted = new Date().toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  const getPageTitle = () => {
    switch (activeTab) {
      case 'home':
        return 'Dashboard';
      case 'new-po':
        return 'Enter Purchase Order';
      case 'confirmation':
        return 'Purchase Order Receipt';
      case 'reports':
        return 'Vendor Purchase Reports';
      default:
        return 'Inventory Management';
    }
  };

  return (
    <div className="app-layout">
      {/* Unique Dark Navy Left Sidebar */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Workspace Area */}
      <div className="app-main">
        {/* Top Action Bar */}
        <header className="top-action-bar no-print">
          <div className="top-left-heading">
            <h1 className="top-page-title">{getPageTitle()}</h1>
            <div className="top-date-chip">
              <Calendar size={13} />
              <span>{todayFormatted}</span>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            {activeTab !== 'new-po' && (
              <button
                className="btn btn-yellow btn-sm"
                onClick={() => setActiveTab('new-po')}
              >
                <PlusCircle size={14} />
                <span>+ New Order</span>
              </button>
            )}
          </div>
        </header>

        {/* Content Canvas */}
        <main className="content-canvas">
          {activeTab === 'home' && (
            <HomePage setActiveTab={setActiveTab} />
          )}

          {activeTab === 'new-po' && (
            <PurchaseOrderForm
              onSuccess={handlePurchaseSuccess}
              onCancel={() => setActiveTab('home')}
            />
          )}

          {activeTab === 'confirmation' && (
            <PurchaseSuccessConfirmation
              purchase={lastCreatedPurchase}
              onNewOrder={handleCreateAnother}
              onViewReports={handleViewVendorReports}
              onBackHome={() => setActiveTab('home')}
            />
          )}

          {activeTab === 'reports' && (
            <PurchaseReports
              initialVendor={reportVendorFilter}
            />
          )}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AppContent />
    </ToastProvider>
  );
}
